import mysql.connector

# Establish connection to MySQL
def connect_to_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",  # Replace with your MySQL username
        password="Anupam#321@Mi",  # Replace with your MySQL password
        database="BankDB"
    )

# Function to create a new account
def create_account():
    name = input("Enter account holder's name: ")
    initial_deposit = float(input("Enter initial deposit amount: "))
    
    db = connect_to_db()
    cursor = db.cursor()
    
    query = "INSERT INTO Accounts (Name, Balance) VALUES (%s, %s)"
    cursor.execute(query, (name, initial_deposit))
    db.commit()1
    
    print(f"Account created successfully! Account ID: {cursor.lastrowid}")
    cursor.close()
    db.close()

# Function to deposit money
def deposit_money():
    account_id = int(input("Enter Account ID: "))
    deposit_amount = float(input("Enter amount to deposit: "))
    
    db = connect_to_db()
    cursor = db.cursor()
    
    query = "UPDATE Accounts SET Balance = Balance + %s WHERE AccountID = %s"
    cursor.execute(query, (deposit_amount, account_id))
    db.commit()
    
    if cursor.rowcount > 0:
        print("Deposit successful!")
    else:
        print("Account not found.")
    
    cursor.close()
    db.close()

# Function to withdraw money
def withdraw_money():
    account_id = int(input("Enter Account ID: "))
    withdrawal_amount = float(input("Enter amount to withdraw: "))
    
    db = connect_to_db()
    cursor = db.cursor()
    
    cursor.execute("SELECT Balance FROM Accounts WHERE AccountID = %s", (account_id,))
    result = cursor.fetchone()
    
    if result:
        current_balance = result[0]
        if withdrawal_amount <= current_balance:
            query = "UPDATE Accounts SET Balance = Balance - %s WHERE AccountID = %s"
            cursor.execute(query, (withdrawal_amount, account_id))
            db.commit()
            print("Withdrawal successful!")
        else:
            print("Insufficient balance!")
    else:
        print("Account not found.")
    
    cursor.close()
    db.close()

# Function to check balance
def check_balance():
    account_id = int(input("Enter Account ID: "))
    
    db = connect_to_db()
    cursor = db.cursor()
    
    query = "SELECT Balance FROM Accounts WHERE AccountID = %s"
    cursor.execute(query, (account_id,))
    result = cursor.fetchone()
    
    if result:
        print(f"Current Balance: {result[0]}")
    else:
        print("Account not found.")
    
    cursor.close()
    db.close()

# Main menu
def main_menu():
    while True:
        print("\n=== Bank Management System ===")
        print("1. Create Account")
        print("2. Deposit Money")
        print("3. Withdraw Money")
        print("4. Check Balance")
        print("5. Exit")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            create_account()
        elif choice == '2':
            deposit_money()
        elif choice == '3':
            withdraw_money()
        elif choice == '4':
            check_balance()
        elif choice == '5':
            print("Thank you for using the Bank Management System!")
            break
        else:
            print("Invalid choice. Please try again.")

# Run the application
if __name__ == "__main__":
    main_menu()


